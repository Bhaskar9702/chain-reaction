package application;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class game extends Application {
	
	private String[] str;
	private String p1, p2, p3, p4, p5, p6, p7, p8;
	
	@FXML
	private Button buttonreset;
	
	@FXML
	private RadioButton radiobutton1, radiobutton2;
	
	@FXML
	private AnchorPane root, pagemain, pagesettings;
	
	@FXML
	private ImageView buttonsettings, buttonresume, buttonplay, buttonback, buttonexit1, buttonexit2;
	
	@FXML
	private MenuButton buttonmenu, player1, player2, player3, player4, player5, player6, player7, player8;
	
	@FXML
	private MenuItem menuitem1, menuitem2, menuitem3, menuitem4 ,menuitem5, menuitem6, menuitem7;
	
	@FXML
	private MenuItem green1, red1, yellow1, blue1, pink1, orange1, violet1, brown1;
	
	@FXML
	private MenuItem green2, red2, yellow2, blue2, pink2, orange2, violet2, brown2;
	
	@FXML
	private MenuItem green3, red3, yellow3, blue3, pink3, orange3, violet3, brown3;
	
	@FXML
	private MenuItem green4, red4, yellow4, blue4, pink4, orange4, violet4, brown4;
	
	@FXML
	private MenuItem green5, red5, yellow5, blue5, pink5, orange5, violet5, brown5;
	
	@FXML
	private MenuItem green6, red6, yellow6, blue6, pink6, orange6, violet6, brown6;
	
	@FXML
	private MenuItem green7, red7, yellow7, blue7, pink7, orange7, violet7, brown7;
	
	@FXML
	private MenuItem green8, red8, yellow8, blue8, pink8, orange8, violet8, brown8;
	
	@FXML
	private ToggleGroup size;
	
//	constructor
	public game() {
		p1 = "green";
		p2 = " red";
		p3 = " yellow";
		p4 = " blue";
		p5 = " pink";
		p6 = " orange";
		p7 = " violet";
		p8 = " brown";
		str = new String[3];
		str[0] = "2";
		str[1] = "9x6";
		str[2] = p1 + p2;
	}
	
//	method to get the details from the str array
	private String GetDetails(int _a) {
		return this.str[_a];
	}
	
//	method to set the details into str array
	private void SetDetails(String _s, int _a) {
		this.str[_a] = _s;
	}
	
	
//	method to handle exit event
	@FXML
	private void Exit(MouseEvent event) {
		if(event.getTarget()==buttonexit1 || event.getTarget()==buttonexit2) {
			System.exit(0);
		}
	}
	
//	method to handle settings event
	@FXML
	private void HandleSettings(MouseEvent event) {
		
//		disabling all buttons to select colour
		player1.setDisable(true);
		player2.setDisable(true);
		player3.setDisable(true);
		player4.setDisable(true);
		player5.setDisable(true);
		player6.setDisable(true);
		player7.setDisable(true);
		player8.setDisable(true);
		
//		settings button is clicked
		if(event.getTarget()==buttonsettings) {
			pagesettings.setVisible(true);
			pagemain.setVisible(false);
		}
		
//		back button is clicked
		else if(event.getTarget()==buttonback) {
			pagemain.setVisible(true);
			pagesettings.setVisible(false);
		}
		
//		2 players selected -> 2 colour buttons enabled
		if(GetDetails(0).equals("2")) {
			SetDetails(p1+p2,2);
			player1.setDisable(false);
			player2.setDisable(false);
		}
		
//		3 players selected -> 3 colour buttons enabled
		else if(GetDetails(0).equals("3")) {
			SetDetails(p1+p2+p3,2);
			player1.setDisable(false);
			player2.setDisable(false);
			player3.setDisable(false);
		}
		
//		4 players selected -> 4 colour buttons enabled
		else if(GetDetails(0).equals("4")) {
			SetDetails(p1+p2+p3+p4,2);
			player1.setDisable(false);
			player2.setDisable(false);
			player3.setDisable(false);
			player4.setDisable(false);
		}
		
//		5 players selected -> 5 colour buttons enabled
		else if(GetDetails(0).equals("5")) {
			SetDetails(p1+p2+p3+p4+p5,2);
			player1.setDisable(false);
			player2.setDisable(false);
			player3.setDisable(false);
			player4.setDisable(false);
			player5.setDisable(false);
		}
		
//		6 players selected -> 6 colour buttons enabled
		else if(GetDetails(0).equals("6")) {
			SetDetails(p1+p2+p3+p4+p5+p6,2);
			player1.setDisable(false);
			player2.setDisable(false);
			player3.setDisable(false);
			player4.setDisable(false);
			player5.setDisable(false);
			player6.setDisable(false);
		}
		
//		7 players selected -> 7 colour buttons enabled
		else if(GetDetails(0).equals("7")) {
			SetDetails(p1+p2+p3+p4+p5+p6+p7,2);
			player1.setDisable(false);
			player2.setDisable(false);
			player3.setDisable(false);
			player4.setDisable(false);
			player5.setDisable(false);
			player6.setDisable(false);
			player7.setDisable(false);
		}
		
//		8 players selected -> 8 colour buttons enabled
		else if(GetDetails(0).equals("8")) {
			SetDetails(p1+p2+p3+p4+p5+p6+p7+p8,2);
			player1.setDisable(false);
			player2.setDisable(false);
			player3.setDisable(false);
			player4.setDisable(false);
			player5.setDisable(false);
			player6.setDisable(false);
			player7.setDisable(false);
			player8.setDisable(false);
		}
		System.out.println(GetDetails(2));
	}
	
//	method to handle play game event
	@FXML
	private void HandlePlay(MouseEvent event) throws Exception {
		
//		play button is selected
		if(event.getTarget()==buttonplay) {
			Stage stage = (Stage) buttonplay.getScene().getWindow();
			WriteToFile();
			grid g = new grid();
			g.start(stage);
			System.out.println("exitting");
		}
	}
	
	@FXML
	private void HandleResume(MouseEvent event) {
		if(event.getTarget()==buttonresume) {
			
			System.out.println("yes");
		}
	}
	
//	method to write into info file
	private void WriteToFile() throws FileNotFoundException, UnsupportedEncodingException{
		PrintWriter w = new PrintWriter("./src/application/info.txt", "UTF-8");
		w.println(GetDetails(0));
		w.println(GetDetails(1));
		w.println(GetDetails(2));
		w.close();
	}
	
//	method to change the label of menu
	@FXML
	private void ChangeMenuLabel(ActionEvent event) {
		
//		menu label & str[2] changed to 2 players
		if(event.getTarget()==menuitem1) {
			buttonmenu.setText("2 Players");
			SetDetails("2",0);
			SetDetails(p1+p2,2);
		}
		
//		menu label & str[2] changed to 3 players
		else if(event.getTarget()==menuitem2) {
			buttonmenu.setText("3 Players");
			SetDetails("3",0);
			SetDetails(p1+p2+p3,2);
		}
		
//		menu label & str[2] changed to 4 players
		else if(event.getTarget()==menuitem3) {
			buttonmenu.setText("4 Players");
			SetDetails("4",0);
			SetDetails(p1+p2+p3+p4,2);
		}
		
//		menu label & str[2] changed to 5 players
		else if(event.getTarget()==menuitem4) {
			buttonmenu.setText("5 Players");
			SetDetails("5",0);
			SetDetails(p1+p2+p3+p4+p5,2);
		}
		
//		menu label & str[2] changed to 6 players
		else if(event.getTarget()==menuitem5) {
			buttonmenu.setText("6 Players");
			SetDetails("6",0);
			SetDetails(p1+p2+p3+p4+p5+p6,2);
		}
		
//		menu label & str[2] changed to 7 players
		else if(event.getTarget()==menuitem6) {
			buttonmenu.setText("7 Players");
			SetDetails("7",0);
			SetDetails(p1+p2+p3+p4+p5+p6+p7,2);
		}
		
//		menu label & str[2] changed to 8 players
		else if(event.getTarget()==menuitem7) {
			buttonmenu.setText("8 Players");
			SetDetails("8",0);
			SetDetails(p1+p2+p3+p4+p5+p6+p7+p8,2);
		}
		System.out.println(GetDetails(0));
	}
	
//	method to handle radio buttons
	@FXML
	private void HandleRadioButton(MouseEvent event) {
		
//		str[1] updated to 9x6
		if(size.getToggles().get(1).isSelected())
			SetDetails("9x6",1);
		
//		str[1] updated to 15x10
		else if(size.getToggles().get(0).isSelected())
			SetDetails("15x10",1);
		System.out.println(GetDetails(1));
	}
	
//	method to change the label of player 1
	@FXML
	private void ChangePlayer1Label(ActionEvent event) {
		
//		array consists of colour buttons
		MenuItem[] items = {green1, red1, yellow1, blue1, pink1, orange1, violet1, brown1};
		MenuItem[] greens = {green1, green2, green3, green4, green5, green6, green7, green8};
		MenuItem[] reds = {red1, red2, red3, red4, red5, red6, red7, red8};
		MenuItem[] yellows = {yellow1, yellow2, yellow3, yellow4, yellow5, yellow6, yellow7, yellow8};
		MenuItem[] blues = {blue1, blue2, blue3, blue4, blue5, blue6, blue7, blue8};
		MenuItem[] pinks = {pink1, pink2, pink3, pink4, pink5, pink6, pink7, pink8};
		MenuItem[] oranges = {orange1, orange2, orange3, orange4, orange5, orange6, orange7, orange8};
		MenuItem[] violets = {violet1, violet2, violet3, violet4, violet5, violet6, violet7, violet8};
		MenuItem[] browns = {brown1, brown2, brown3, brown4, brown5, brown6, brown7, brown8};
		
//		player 1 selected green -> rest colours disabled for player 1 & green disabled for rest players
		if(event.getTarget()==green1) {
			player1.setStyle("-fx-text-fill: #00ff00");
			p1 = "green";
			for(int i=0; i<8; i++) {
				if(items[i]!=green1)
					items[i].setDisable(true);
				if(greens[i]!=green1)
					greens[i].setDisable(true);
			}
		}
		
//		player 1 selected red -> rest colours disabled for player 1 & red disabled for rest players
		else if(event.getTarget()==red1) {
			player1.setStyle("-fx-text-fill: #ff0000");
			p1 = "red";
			for(int i=0; i<8; i++) {
				if(items[i]!=red1)
					items[i].setDisable(true);
				if(reds[i]!=red1)
					reds[i].setDisable(true);
			}
		}
		
//		player 1 selected yellow -> rest colours disabled for player 1 & yellow disabled for rest players
		else if(event.getTarget()==yellow1) {
			player1.setStyle("-fx-text-fill: #feff00");
			p1 = "yellow";
			for(int i=0; i<8; i++) {
				if(items[i]!=yellow1)
					items[i].setDisable(true);
				if(yellows[i]!=yellow1)
					yellows[i].setDisable(true);
			}
		}
		
//		player 1 selected blue -> rest colours disabled for player 1 & blue disabled for rest players
		else if(event.getTarget()==blue1) {
			player1.setStyle("-fx-text-fill: #0049ff");
			p1 = "blue";
			for(int i=0; i<8; i++) {
				if(items[i]!=blue1)
					items[i].setDisable(true);
				if(blues[i]!=blue1)
					blues[i].setDisable(true);
			}
		}
		
//		player 1 selected pink -> rest colours disabled for player 1 & pink disabled for rest players
		else if(event.getTarget()==pink1) {
			player1.setStyle("-fx-text-fill: #ff00bf");
			p1 = "pink";
			for(int i=0; i<8; i++) {
				if(items[i]!=pink1)
					items[i].setDisable(true);
				if(pinks[i]!=pink1)
					pinks[i].setDisable(true);
			}
		}
		
//		player 1 selected orange -> rest colours disabled for player 1 & orange disabled for rest players
		else if(event.getTarget()==orange1) {
			player1.setStyle("-fx-text-fill: #ff9c00");
			p1 = "orange";
			for(int i=0; i<8; i++) {
				if(items[i]!=orange1)
					items[i].setDisable(true);
				if(oranges[i]!=orange1)
					oranges[i].setDisable(true);
			}
		}
		
//		player 1 selected violet -> rest colours disabled for player 1 & violet disabled for rest players
		else if(event.getTarget()==violet1) {
			player1.setStyle("-fx-text-fill: #ae00ff");
			p1 = "violet";
			for(int i=0; i<8; i++) {
				if(items[i]!=violet1)
					items[i].setDisable(true);
				if(violets[i]!=violet1)
					violets[i].setDisable(true);
			}
		}
		
//		player 1 selected brown -> rest colours disabled for player 1 & brown disabled for rest players
		else if(event.getTarget()==brown1) {
			player1.setStyle("-fx-text-fill: #a73d0c");
			p1 = "brown";
			for(int i=0; i<8; i++) {
				if(items[i]!=brown1)
					items[i].setDisable(true);
				if(browns[i]!=brown1)
					browns[i].setDisable(true);
			}
		}
	}
	
//	method to change the label of player 2
	@FXML
	private void ChangePlayer2Label(ActionEvent event) {
		
//		array consists of colour buttons
		MenuItem[] items = {green2, red2, yellow2, blue2, pink2, orange2, violet2, brown2};
		MenuItem[] greens = {green1, green2, green3, green4, green5, green6, green7, green8};
		MenuItem[] reds = {red1, red2, red3, red4, red5, red6, red7, red8};
		MenuItem[] yellows = {yellow1, yellow2, yellow3, yellow4, yellow5, yellow6, yellow7, yellow8};
		MenuItem[] blues = {blue1, blue2, blue3, blue4, blue5, blue6, blue7, blue8};
		MenuItem[] pinks = {pink1, pink2, pink3, pink4, pink5, pink6, pink7, pink8};
		MenuItem[] oranges = {orange1, orange2, orange3, orange4, orange5, orange6, orange7, orange8};
		MenuItem[] violets = {violet1, violet2, violet3, violet4, violet5, violet6, violet7, violet8};
		MenuItem[] browns = {brown1, brown2, brown3, brown4, brown5, brown6, brown7, brown8};
		
//		player 2 selected green -> rest colours disabled for player 2 & green disabled for rest players
		if(event.getTarget()==green2) {
			player2.setStyle("-fx-text-fill: #00ff00");
			p2 = " green";
			for(int i=0; i<8; i++) {
				if(items[i]!=green2)
					items[i].setDisable(true);
				if(greens[i]!=green2)
					greens[i].setDisable(true);
			}
		}
		
//		player 2 selected red -> rest colours disabled for player 2 & red disabled for rest players
		else if(event.getTarget()==red2) {
			player2.setStyle("-fx-text-fill: #ff0000");
			p2 = " red";
			for(int i=0; i<8; i++) {
				if(items[i]!=red2)
					items[i].setDisable(true);
				if(reds[i]!=red2)
					reds[i].setDisable(true);
			}
		}
		
//		player 2 selected yellow -> rest colours disabled for player 2 & yellow disabled for rest players
		else if(event.getTarget()==yellow2) {
			player2.setStyle("-fx-text-fill: #feff00");
			p2 = " yellow";
			for(int i=0; i<8; i++) {
				if(items[i]!=yellow2)
					items[i].setDisable(true);
				if(yellows[i]!=yellow2)
					yellows[i].setDisable(true);
			}
		}
		
//		player 2 selected blue -> rest colours disabled for player 2 & blue disabled for rest players
		else if(event.getTarget()==blue2) {
			player2.setStyle("-fx-text-fill: #0049ff");
			p2 = " blue";
			for(int i=0; i<8; i++) {
				if(items[i]!=blue2)
					items[i].setDisable(true);
				if(blues[i]!=blue2)
					blues[i].setDisable(true);
			}
		}
		
//		player 2 selected pink -> rest colours disabled for player 2 & pink disabled for rest players
		else if(event.getTarget()==pink2) {
			player2.setStyle("-fx-text-fill: #ff00bf");
			p2 = " pink";
			for(int i=0; i<8; i++) {
				if(items[i]!=pink2)
					items[i].setDisable(true);
				if(pinks[i]!=pink2)
					pinks[i].setDisable(true);
			}
		}
		
//		player 2 selected orange -> rest colours disabled for player 2 & orange disabled for rest players
		else if(event.getTarget()==orange2) {
			player2.setStyle("-fx-text-fill: #ff9c00");
			p2 = " orange";
			for(int i=0; i<8; i++) {
				if(items[i]!=orange2)
					items[i].setDisable(true);
				if(oranges[i]!=orange2)
					oranges[i].setDisable(true);
			}
		}
		
//		player 2 selected violet -> rest colours disabled for player 2 & violet disabled for rest players
		else if(event.getTarget()==violet2) {
			player2.setStyle("-fx-text-fill: #ae00ff");
			p2 = " violet";
			for(int i=0; i<8; i++) {
				if(items[i]!=violet2)
					items[i].setDisable(true);
				if(violets[i]!=violet2)
					violets[i].setDisable(true);
			}
		}
		
//		player 2 selected brown -> rest colours disabled for player 2 & brown disabled for rest players
		else if(event.getTarget()==brown2) {
			player2.setStyle("-fx-text-fill: #a73d0c");
			p2 = " brown";
			for(int i=0; i<8; i++) {
				if(items[i]!=brown2)
					items[i].setDisable(true);
				if(browns[i]!=brown2)
					browns[i].setDisable(true);
			}
		}
	}
	
//	method to change the label of player 3
	@FXML
	private void ChangePlayer3Label(ActionEvent event) {
		
//		array consists of colour buttons
		MenuItem[] items = {green3, red3, yellow3, blue3, pink3, orange3, violet3, brown3};
		MenuItem[] greens = {green1, green2, green3, green4, green5, green6, green7, green8};
		MenuItem[] reds = {red1, red2, red3, red4, red5, red6, red7, red8};
		MenuItem[] yellows = {yellow1, yellow2, yellow3, yellow4, yellow5, yellow6, yellow7, yellow8};
		MenuItem[] blues = {blue1, blue2, blue3, blue4, blue5, blue6, blue7, blue8};
		MenuItem[] pinks = {pink1, pink2, pink3, pink4, pink5, pink6, pink7, pink8};
		MenuItem[] oranges = {orange1, orange2, orange3, orange4, orange5, orange6, orange7, orange8};
		MenuItem[] violets = {violet1, violet2, violet3, violet4, violet5, violet6, violet7, violet8};
		MenuItem[] browns = {brown1, brown2, brown3, brown4, brown5, brown6, brown7, brown8};
		
//		player 3 selected green -> rest colours disabled for player 3 & green disabled for rest players
		if(event.getTarget()==green3) {
			player3.setStyle("-fx-text-fill: #00ff00");
			p3 = " green";
			for(int i=0; i<8; i++) {
				if(items[i]!=green3)
					items[i].setDisable(true);
				if(greens[i]!=green3)
					greens[i].setDisable(true);
			}
		}
		
//		player 3 selected red -> rest colours disabled for player 3 & red disabled for rest players
		else if(event.getTarget()==red3) {
			player3.setStyle("-fx-text-fill: #ff0000");
			p3 = " red";
			for(int i=0; i<8; i++) {
				if(items[i]!=red3)
					items[i].setDisable(true);
				if(reds[i]!=red3)
					reds[i].setDisable(true);
			}
		}
		
//		player 3 selected yellow -> rest colours disabled for player 3 & yellow disabled for rest players
		else if(event.getTarget()==yellow3) {
			player3.setStyle("-fx-text-fill: #feff00");
			p3 = " yellow";
			for(int i=0; i<8; i++) {
				if(items[i]!=yellow3)
					items[i].setDisable(true);
				if(yellows[i]!=yellow3)
					yellows[i].setDisable(true);
			}
		}
		
//		player 3 selected blue -> rest colours disabled for player 3 & blue disabled for rest players
		else if(event.getTarget()==blue3) {
			player3.setStyle("-fx-text-fill: #0049ff");
			p3 = " blue";
			for(int i=0; i<8; i++) {
				if(items[i]!=blue3)
					items[i].setDisable(true);
				if(blues[i]!=blue3)
					blues[i].setDisable(true);
			}
		}
		
//		player 3 selected pink -> rest colours disabled for player 3 & pink disabled for rest players
		else if(event.getTarget()==pink3) {
			player3.setStyle("-fx-text-fill: #ff00bf");
			p3 = " pink";
			for(int i=0; i<8; i++) {
				if(items[i]!=pink3)
					items[i].setDisable(true);
				if(pinks[i]!=pink3)
					pinks[i].setDisable(true);
			}
		}
		
//		player 3 selected orange -> rest colours disabled for player 3 & orange disabled for rest players
		else if(event.getTarget()==orange3) {
			player3.setStyle("-fx-text-fill: #ff9c00");
			p3 = " orange";
			for(int i=0; i<8; i++) {
				if(items[i]!=orange3)
					items[i].setDisable(true);
				if(oranges[i]!=orange3)
					oranges[i].setDisable(true);
			}
		}
		
//		player 3 selected violet -> rest colours disabled for player 3 & violet disabled for rest players
		else if(event.getTarget()==violet3) {
			player3.setStyle("-fx-text-fill: #ae00ff");
			p3 = " violet";
			for(int i=0; i<8; i++) {
				if(items[i]!=violet3)
					items[i].setDisable(true);
				if(violets[i]!=violet3)
					violets[i].setDisable(true);
			}
		}
		
//		player 3 selected brown -> rest colours disabled for player 3 & brown disabled for rest players
		else if(event.getTarget()==brown3) {
			player3.setStyle("-fx-text-fill: #a73d0c");
			p3 = " brown";
			for(int i=0; i<8; i++) {
				if(items[i]!=brown3)
					items[i].setDisable(true);
				if(browns[i]!=brown3)
					browns[i].setDisable(true);
			}
		}
	}
	
//	method to change the label of player 4
	@FXML
	private void ChangePlayer4Label(ActionEvent event) {
		
//		array consists of colour buttons
		MenuItem[] items = {green4, red4, yellow4, blue4, pink4, orange4, violet4, brown4};
		MenuItem[] greens = {green1, green2, green3, green4, green5, green6, green7, green8};
		MenuItem[] reds = {red1, red2, red3, red4, red5, red6, red7, red8};
		MenuItem[] yellows = {yellow1, yellow2, yellow3, yellow4, yellow5, yellow6, yellow7, yellow8};
		MenuItem[] blues = {blue1, blue2, blue3, blue4, blue5, blue6, blue7, blue8};
		MenuItem[] pinks = {pink1, pink2, pink3, pink4, pink5, pink6, pink7, pink8};
		MenuItem[] oranges = {orange1, orange2, orange3, orange4, orange5, orange6, orange7, orange8};
		MenuItem[] violets = {violet1, violet2, violet3, violet4, violet5, violet6, violet7, violet8};
		MenuItem[] browns = {brown1, brown2, brown3, brown4, brown5, brown6, brown7, brown8};
		
//		player 4 selected green -> rest colours disabled for player 4 & green disabled for rest players
		if(event.getTarget()==green4) {
			player4.setStyle("-fx-text-fill: #00ff00");
			p4 = " green";
			for(int i=0; i<8; i++) {
				if(items[i]!=green4)
					items[i].setDisable(true);
				if(greens[i]!=green4)
					greens[i].setDisable(true);
			}
		}
		
//		player 4 selected red -> rest colours disabled for player 4 & red disabled for rest players
		else if(event.getTarget()==red4) {
			player4.setStyle("-fx-text-fill: #ff0000");
			p4 = " red";
			for(int i=0; i<8; i++) {
				if(items[i]!=red4)
					items[i].setDisable(true);
				if(reds[i]!=red4)
					reds[i].setDisable(true);
			}
		}
		
//		player 4 selected yellow -> rest colours disabled for player 4 & yellow disabled for rest players
		else if(event.getTarget()==yellow4) {
			player4.setStyle("-fx-text-fill: #feff00");
			p4 = " yellow";
			for(int i=0; i<8; i++) {
				if(items[i]!=yellow4)
					items[i].setDisable(true);
				if(yellows[i]!=yellow4)
					yellows[i].setDisable(true);
			}
		}
		
//		player 4 selected blue -> rest colours disabled for player 4 & blue disabled for rest players
		else if(event.getTarget()==blue4) {
			player4.setStyle("-fx-text-fill: #0049ff");
			p4 = " blue";
			for(int i=0; i<8; i++) {
				if(items[i]!=blue4)
					items[i].setDisable(true);
				if(blues[i]!=blue4)
					blues[i].setDisable(true);
			}
		}
		
//		player 4 selected pink -> rest colours disabled for player 4 & pink disabled for rest players
		else if(event.getTarget()==pink4) {
			player4.setStyle("-fx-text-fill: #ff00bf");
			p4 = " pink";
			for(int i=0; i<8; i++) {
				if(items[i]!=pink4)
					items[i].setDisable(true);
				if(pinks[i]!=pink4)
					pinks[i].setDisable(true);
			}
		}
		
//		player 4 selected orange -> rest colours disabled for player 4 & orange disabled for rest players
		else if(event.getTarget()==orange4) {
			player4.setStyle("-fx-text-fill: #ff9c00");
			p4 = " orange";
			for(int i=0; i<8; i++) {
				if(items[i]!=orange4)
					items[i].setDisable(true);
				if(oranges[i]!=orange4)
					oranges[i].setDisable(true);
			}
		}
		
//		player 4 selected violet -> rest colours disabled for player 4 & violet disabled for rest players
		else if(event.getTarget()==violet4) {
			player4.setStyle("-fx-text-fill: #ae00ff");
			p4 = " violet";
			for(int i=0; i<8; i++) {
				if(items[i]!=violet4)
					items[i].setDisable(true);
				if(violets[i]!=violet4)
					violets[i].setDisable(true);
			}
		}
		
//		player 4 selected brown -> rest colours disabled for player 4 & brown disabled for rest players
		else if(event.getTarget()==brown4) {
			player4.setStyle("-fx-text-fill: #a73d0c");
			p4 = " brown";
			for(int i=0; i<8; i++) {
				if(items[i]!=brown4)
					items[i].setDisable(true);
				if(browns[i]!=brown4)
					browns[i].setDisable(true);
			}
		}
	}
	
//	method to change the label of player 5
	@FXML
	private void ChangePlayer5Label(ActionEvent event) {
		
//		array consits of colour buttons
		MenuItem[] items = {green5, red5, yellow5, blue5, pink5, orange5, violet5, brown5};
		MenuItem[] greens = {green1, green2, green3, green4, green5, green6, green7, green8};
		MenuItem[] reds = {red1, red2, red3, red4, red5, red6, red7, red8};
		MenuItem[] yellows = {yellow1, yellow2, yellow3, yellow4, yellow5, yellow6, yellow7, yellow8};
		MenuItem[] blues = {blue1, blue2, blue3, blue4, blue5, blue6, blue7, blue8};
		MenuItem[] pinks = {pink1, pink2, pink3, pink4, pink5, pink6, pink7, pink8};
		MenuItem[] oranges = {orange1, orange2, orange3, orange4, orange5, orange6, orange7, orange8};
		MenuItem[] violets = {violet1, violet2, violet3, violet4, violet5, violet6, violet7, violet8};
		MenuItem[] browns = {brown1, brown2, brown3, brown4, brown5, brown6, brown7, brown8};
		
//		player 5 selected green -> rest colours disabled for player 5 & green disabled for rest players
		if(event.getTarget()==green5) {
			player5.setStyle("-fx-text-fill: #00ff00");
			p5 = " green";
			for(int i=0; i<8; i++) {
				if(items[i]!=green5)
					items[i].setDisable(true);
				if(greens[i]!=green5)
					greens[i].setDisable(true);
			}
		}
		
//		player 5 selected red -> rest colours disabled for player 5 & red disabled for rest players
		else if(event.getTarget()==red5) {
			player5.setStyle("-fx-text-fill: #ff0000");
			p5 = " red";
			for(int i=0; i<8; i++) {
				if(items[i]!=red5)
					items[i].setDisable(true);
				if(reds[i]!=red5)
					reds[i].setDisable(true);
			}
		}
		
//		player 5 selected yellow -> rest colours disabled for player 5 & yellow disabled for rest players
		else if(event.getTarget()==yellow5) {
			player5.setStyle("-fx-text-fill: #feff00");
			p5 = " yellow";
			for(int i=0; i<8; i++) {
				if(items[i]!=yellow5)
					items[i].setDisable(true);
				if(yellows[i]!=yellow5)
					yellows[i].setDisable(true);
			}
		}
		
//		player 5 selected blue -> rest colours disabled for player 5 & blue disabled for rest players
		else if(event.getTarget()==blue5) {
			player5.setStyle("-fx-text-fill: #0049ff");
			p5 = " blue";
			for(int i=0; i<8; i++) {
				if(items[i]!=blue5)
					items[i].setDisable(true);
				if(blues[i]!=blue5)
					blues[i].setDisable(true);
			}
		}
		
//		player 5 selected pink -> rest colours disabled for player 5 & pink disabled for rest players
		else if(event.getTarget()==pink5) {
			player5.setStyle("-fx-text-fill: #ff00bf");
			p5 = " pink";
			for(int i=0; i<8; i++) {
				if(items[i]!=pink5)
					items[i].setDisable(true);
				if(pinks[i]!=pink5)
					pinks[i].setDisable(true);
			}
		}
		
//		player 5 selected orange -> rest colours disabled for player 5 & orange disabled for rest players
		else if(event.getTarget()==orange5) {
			player5.setStyle("-fx-text-fill: #ff9c00");
			p5 = " orange";
			for(int i=0; i<8; i++) {
				if(items[i]!=orange5)
					items[i].setDisable(true);
				if(oranges[i]!=orange5)
					oranges[i].setDisable(true);
			}
		}
		
//		player 5 selected violet -> rest colours disabled for player 5 & violet disabled for rest players
		else if(event.getTarget()==violet5) {
			player5.setStyle("-fx-text-fill: #ae00ff");
			p5 = " violet";
			for(int i=0; i<8; i++) {
				if(items[i]!=violet5)
					items[i].setDisable(true);
				if(violets[i]!=violet5)
					violets[i].setDisable(true);
			}
		}
		
//		player 5 selected brown -> rest colours disabled for player 5 & brown disabled for rest players
		else if(event.getTarget()==brown5) {
			player5.setStyle("-fx-text-fill: #a73d0c");
			p5 = " brown";
			for(int i=0; i<8; i++) {
				if(items[i]!=brown5)
					items[i].setDisable(true);
				if(browns[i]!=brown5)
					browns[i].setDisable(true);
			}
		}
	}
	
//	method to change the label of player 6
	@FXML
	private void ChangePlayer6Label(ActionEvent event) {
		
//		array consists of colour buttons
		MenuItem[] items = {green6, red6, yellow6, blue6, pink6, orange6, violet6, brown6};
		MenuItem[] greens = {green1, green2, green3, green4, green5, green6, green7, green8};
		MenuItem[] reds = {red1, red2, red3, red4, red5, red6, red7, red8};
		MenuItem[] yellows = {yellow1, yellow2, yellow3, yellow4, yellow5, yellow6, yellow7, yellow8};
		MenuItem[] blues = {blue1, blue2, blue3, blue4, blue5, blue6, blue7, blue8};
		MenuItem[] pinks = {pink1, pink2, pink3, pink4, pink5, pink6, pink7, pink8};
		MenuItem[] oranges = {orange1, orange2, orange3, orange4, orange5, orange6, orange7, orange8};
		MenuItem[] violets = {violet1, violet2, violet3, violet4, violet5, violet6, violet7, violet8};
		MenuItem[] browns = {brown1, brown2, brown3, brown4, brown5, brown6, brown7, brown8};
		
//		player 6 selected green -> rest colours disabled for player 6 & green disabled for rest players
		if(event.getTarget()==green6) {
			player6.setStyle("-fx-text-fill: #00ff00");
			p6 = " green";
			for(int i=0; i<8; i++) {
				if(items[i]!=green6)
					items[i].setDisable(true);
				if(greens[i]!=green6)
					greens[i].setDisable(true);
			}
		}
		
//		player 6 selected red -> rest colours disabled for player 6 & red disabled for rest players
		else if(event.getTarget()==red6) {
			player6.setStyle("-fx-text-fill: #ff0000");
			p6 = " red";
			for(int i=0; i<8; i++) {
				if(items[i]!=red6)
					items[i].setDisable(true);
				if(reds[i]!=red6)
					reds[i].setDisable(true);
			}
		}
		
//		player 6 selected yellow -> rest colours disabled for player 6 & yellow disabled for rest players
		else if(event.getTarget()==yellow6) {
			player6.setStyle("-fx-text-fill: #feff00");
			p6 = " yellow";
			for(int i=0; i<8; i++) {
				if(items[i]!=yellow6)
					items[i].setDisable(true);
				if(yellows[i]!=yellow6)
					yellows[i].setDisable(true);
			}		
		}
		
//		player 6 selected blue -> rest colours disabled for player 6 & blue disabled for rest players
		else if(event.getTarget()==blue6) {
			player6.setStyle("-fx-text-fill: #0049ff");
			p6 = " blue";
			for(int i=0; i<8; i++) {
				if(items[i]!=blue6)
					items[i].setDisable(true);
				if(blues[i]!=blue6)
					blues[i].setDisable(true);
			}
		}
		
//		player 6 selected pink -> rest colours disabled for player 6 & pink disabled for rest players
		else if(event.getTarget()==pink6) {
			player6.setStyle("-fx-text-fill: #ff00bf");
			p6 = " pink";
			for(int i=0; i<8; i++) {
				if(items[i]!=pink6)
					items[i].setDisable(true);
				if(pinks[i]!=pink6)
					pinks[i].setDisable(true);
			}
		}
		
//		player 6 selected orange -> rest colours disabled for player 6 & orange disabled for rest players
		else if(event.getTarget()==orange6) {
			player6.setStyle("-fx-text-fill: #ff9c00");
			p6 = " orange";
			for(int i=0; i<8; i++) {
				if(items[i]!=orange6)
					items[i].setDisable(true);
				if(oranges[i]!=orange6)
					oranges[i].setDisable(true);
			}
		}
		
//		player 6 selected violet -> rest colours disabled for player 6 & violet disabled for rest players
		else if(event.getTarget()==violet6) {
			player6.setStyle("-fx-text-fill: #ae00ff");
			p6 = " violet";
			for(int i=0; i<8; i++) {
				if(items[i]!=violet6)
					items[i].setDisable(true);
				if(violets[i]!=violet6)
					violets[i].setDisable(true);
			}
		}
		
//		player 6 selected brown -> rest colours disabled for player 6 & brown disabled for rest players
		else if(event.getTarget()==brown6) {
			player6.setStyle("-fx-text-fill: #a73d0c");
			p6 = " brown";
			for(int i=0; i<8; i++) {
				if(items[i]!=brown6)
					items[i].setDisable(true);
				if(browns[i]!=brown6)
					browns[i].setDisable(true);
			}
		}
	}
	
//	method to change the label of player 7
	@FXML
	private void ChangePlayer7Label(ActionEvent event) {
		
//		array consists of colour buttons
		MenuItem[] items = {green7, red7, yellow7, blue7, pink7, orange7, violet7, brown7};
		MenuItem[] greens = {green1, green2, green3, green4, green5, green6, green7, green8};
		MenuItem[] reds = {red1, red2, red3, red4, red5, red6, red7, red8};
		MenuItem[] yellows = {yellow1, yellow2, yellow3, yellow4, yellow5, yellow6, yellow7, yellow8};
		MenuItem[] blues = {blue1, blue2, blue3, blue4, blue5, blue6, blue7, blue8};
		MenuItem[] pinks = {pink1, pink2, pink3, pink4, pink5, pink6, pink7, pink8};
		MenuItem[] oranges = {orange1, orange2, orange3, orange4, orange5, orange6, orange7, orange8};
		MenuItem[] violets = {violet1, violet2, violet3, violet4, violet5, violet6, violet7, violet8};
		MenuItem[] browns = {brown1, brown2, brown3, brown4, brown5, brown6, brown7, brown8};
		
//		player 7 selected green -> rest colours disabled for player 7 & green disabled for rest players
		if(event.getTarget()==green7) {
			player7.setStyle("-fx-text-fill: #00ff00");
			p7 = " green";
			for(int i=0; i<8; i++) {
				if(items[i]!=green7)
					items[i].setDisable(true);
				if(greens[i]!=green7)
					greens[i].setDisable(true);
			}
		}
		
//		player 7 selected red -> rest colours disabled for player 7 & red disabled for rest players
		else if(event.getTarget()==red7) {
			player7.setStyle("-fx-text-fill: #ff0000");
			p7 = " red";
			for(int i=0; i<8; i++) {
				if(items[i]!=red7)
					items[i].setDisable(true);
				if(reds[i]!=red7)
					reds[i].setDisable(true);
			}
		}
		
//		player 7 selected yellow -> rest colours disabled for player 7 & yellow disabled for rest players
		else if(event.getTarget()==yellow7) {
			player7.setStyle("-fx-text-fill: #feff00");
			p7 = " yellow";
			for(int i=0; i<8; i++) {
				if(items[i]!=yellow7)
					items[i].setDisable(true);
				if(yellows[i]!=yellow7)
					yellows[i].setDisable(true);
			}			
		}
		
//		player 7 selected blue -> rest colours disabled for player 7 & blue disabled for rest players
		else if(event.getTarget()==blue7) {
			player7.setStyle("-fx-text-fill: #0049ff");
			p7 = " blue";
			for(int i=0; i<8; i++) {
				if(items[i]!=blue7)
					items[i].setDisable(true);
				if(blues[i]!=blue7)
					blues[i].setDisable(true);
			}
		}
		
//		player 7 selected pink -> rest colours disabled for player 7 & pink disabled for rest players
		else if(event.getTarget()==pink7) {
			player7.setStyle("-fx-text-fill: #ff00bf");
			p7 = " pink";
			for(int i=0; i<8; i++) {
				if(items[i]!=pink7)
					items[i].setDisable(true);
				if(pinks[i]!=pink7)
					pinks[i].setDisable(true);
			}
		}
		
//		player 7 selected orange -> rest colours disabled for player 7 & orange disabled for rest players
		else if(event.getTarget()==orange7) {
			player7.setStyle("-fx-text-fill: #ff9c00");
			p7 = " orange";
			for(int i=0; i<8; i++) {
				if(items[i]!=orange7)
					items[i].setDisable(true);
				if(oranges[i]!=orange7)
					oranges[i].setDisable(true);
			}
		}
		
//		player 7 selected violet -> rest colours disabled for player 7 & violet disabled for rest players
		else if(event.getTarget()==violet7) {
			player7.setStyle("-fx-text-fill: #ae00ff");
			p7 = " violet";
			for(int i=0; i<8; i++) {
				if(items[i]!=violet7)
					items[i].setDisable(true);
				if(violets[i]!=violet7)
					violets[i].setDisable(true);
			}
		}
		
//		player 7 selected brown -> rest colours disabled for player 7 & brown disabled for rest players
		else if(event.getTarget()==brown7) {
			player7.setStyle("-fx-text-fill: #a73d0c");
			p7 = " brown";
			for(int i=0; i<8; i++) {
				if(items[i]!=brown7)
					items[i].setDisable(true);
				if(browns[i]!=brown7)
					browns[i].setDisable(true);
			}
		}
	}
	
//	method to change the label of player 8
	@FXML
	private void ChangePlayer8Label(ActionEvent event) {
		
//		array consists of colour buttons
		MenuItem[] items = {green8, red8, yellow8, blue8, pink8, orange8, violet8, brown8};
		MenuItem[] greens = {green1, green2, green3, green4, green5, green6, green7, green8};
		MenuItem[] reds = {red1, red2, red3, red4, red5, red6, red7, red8};
		MenuItem[] yellows = {yellow1, yellow2, yellow3, yellow4, yellow5, yellow6, yellow7, yellow8};
		MenuItem[] blues = {blue1, blue2, blue3, blue4, blue5, blue6, blue7, blue8};
		MenuItem[] pinks = {pink1, pink2, pink3, pink4, pink5, pink6, pink7, pink8};
		MenuItem[] oranges = {orange1, orange2, orange3, orange4, orange5, orange6, orange7, orange8};
		MenuItem[] violets = {violet1, violet2, violet3, violet4, violet5, violet6, violet7, violet8};
		MenuItem[] browns = {brown1, brown2, brown3, brown4, brown5, brown6, brown7, brown8};
		
//		player 8 selected green -> rest colours disabled for player 8 & green disabled for rest players
		if(event.getTarget()==green8) {
			player8.setStyle("-fx-text-fill: #00ff00");
			p8 = " green";
			for(int i=0; i<8; i++) {
				if(items[i]!=green8)
					items[i].setDisable(true);
				if(greens[i]!=green8)
					greens[i].setDisable(true);
			}
		}
		
//		player 7 selected red -> rest colours disabled for player 7 & red disabled for rest players
		else if(event.getTarget()==red8) {
			player8.setStyle("-fx-text-fill: #ff0000");
			p8 = " red";
			for(int i=0; i<8; i++) {
				if(items[i]!=red8)
					items[i].setDisable(true);
				if(reds[i]!=red8)
					reds[i].setDisable(true);
			}
		}
		
//		player 7 selected yellow -> rest colours disabled for player 7 & yellow disabled for rest players
		else if(event.getTarget()==yellow8) {
			player8.setStyle("-fx-text-fill: #feff00");
			p8 = " yellow";
			for(int i=0; i<8; i++) {
				if(items[i]!=yellow8)
					items[i].setDisable(true);
				if(yellows[i]!=yellow8)
					yellows[i].setDisable(true);
			}
		}
		
//		player 7 selected blue -> rest colours disabled for player 7 & blue disabled for rest players
		else if(event.getTarget()==blue8) {
			player8.setStyle("-fx-text-fill: #0049ff");
			p8 = " blue";
			for(int i=0; i<8; i++) {
				if(items[i]!=blue8)
					items[i].setDisable(true);
				if(blues[i]!=blue8)
					blues[i].setDisable(true);
			}
		}
		
//		player 7 selected pink -> rest colours disabled for player 7 & pink disabled for rest players
		else if(event.getTarget()==pink8) {
			player8.setStyle("-fx-text-fill: #ff00bf");
			p8 = " pink";
			for(int i=0; i<8; i++) {
				if(items[i]!=pink8)
					items[i].setDisable(true);
				if(pinks[i]!=pink8)
					pinks[i].setDisable(true);
			}
		}
		
//		player 7 selected orange -> rest colours disabled for player 7 & orange disabled for rest players
		else if(event.getTarget()==orange8) {
			player8.setStyle("-fx-text-fill: #ff9c00");
			p8 = " orange";
			for(int i=0; i<8; i++) {
				if(items[i]!=orange8)
					items[i].setDisable(true);
				if(oranges[i]!=orange8)
					oranges[i].setDisable(true);
			}
		}
		
//		player 7 selected violet -> rest colours disabled for player 7 & violet disabled for rest players
		else if(event.getTarget()==violet8) {
			player8.setStyle("-fx-text-fill: #ae00ff");
			p8 = " violet";
			for(int i=0; i<8; i++) {
				if(items[i]!=violet8)
					items[i].setDisable(true);
				if(violets[i]!=violet8)
					violets[i].setDisable(true);
			}
		}
		
//		player 7 selected brown -> rest colours disabled for player 7 & brown disabled for rest players
		else if(event.getTarget()==brown8) {
			player8.setStyle("-fx-text-fill: #a73d0c");
			p8 = " brown";
			for(int i=0; i<8; i++) {
				if(items[i]!=brown8)
					items[i].setDisable(true);
				if(browns[i]!=brown8)
					browns[i].setDisable(true);
			}
		}
	}
	
//	method to handle the reset button event
	@FXML
	private void HandleReset(ActionEvent event) {
		
//		array consists of colour buttons
		MenuItem[] greens = {green1, green2, green3, green4, green5, green6, green7, green8};
		MenuItem[] reds = {red1, red2, red3, red4, red5, red6, red7, red8};
		MenuItem[] yellows = {yellow1, yellow2, yellow3, yellow4, yellow5, yellow6, yellow7, yellow8};
		MenuItem[] blues = {blue1, blue2, blue3, blue4, blue5, blue6, blue7, blue8};
		MenuItem[] pinks = {pink1, pink2, pink3, pink4, pink5, pink6, pink7, pink8};
		MenuItem[] oranges = {orange1, orange2, orange3, orange4, orange5, orange6, orange7, orange8};
		MenuItem[] violets = {violet1, violet2, violet3, violet4, violet5, violet6, violet7, violet8};
		MenuItem[] browns = {brown1, brown2, brown3, brown4, brown5, brown6, brown7, brown8};
		
//		reset button is selected
		if(event.getTarget()==buttonreset) {
			System.out.println(event.getTarget());
			for(int i=0; i<8; i++) {
				
//				all colours are enabled for every player
				greens[i].setDisable(false);
				reds[i].setDisable(false);
				yellows[i].setDisable(false);
				blues[i].setDisable(false);
				pinks[i].setDisable(false);
				oranges[i].setDisable(false);
				violets[i].setDisable(false);
				browns[i].setDisable(false);
			}
			
//			label colour is back to white
			player1.setStyle("-fx-text-fill: #ffffff");
			player2.setStyle("-fx-text-fill: #ffffff");
			player3.setStyle("-fx-text-fill: #ffffff");
			player4.setStyle("-fx-text-fill: #ffffff");
			player5.setStyle("-fx-text-fill: #ffffff");
			player6.setStyle("-fx-text-fill: #ffffff");
			player7.setStyle("-fx-text-fill: #ffffff");
			player8.setStyle("-fx-text-fill: #ffffff");
		}
	}
	
	@Override
	public void start(Stage stage) throws Exception {
		try {
			root = FXMLLoader.load(getClass().getResource("mainpage.fxml"));
			stage.initStyle(StageStyle.UNDECORATED);
			stage.centerOnScreen();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();
		}
		catch(Exception e) {
			System.out.println("error --> "+e.getMessage());
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
