package application;
class Player{
	private String color;
	private int count=0;
	private boolean check=false;
	public void check(boolean s) {
		check=s;
	}
	public boolean get_check() {
		return check;
	}
	public int get_count() {
		return count;
	}
	public void set_count(int s) {
		count=s;
	}
	public void inc_count() {
		count=count+1;
	}
	public Player(String c) {
		this.color=c;
	}
	public String get_color() {
		return this.color;
	}
}