package application;
//package application;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Scanner;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class grid extends Application{
	
	@FXML
	AnchorPane game;
	
	@FXML
	private Button buttonundo;
	
	@FXML
	private MenuButton buttonmenu;
	
	@FXML
	private Stage sc;
	grid f;
	Cell[][] s;
	Player[] player;
	Group grt=new Group();
	Group root=new Group();
	public Group  get_root() {
		return root;
	}
	public void set_root(Group s) {
		root=s;
	}
	public Group get_grt() {
		return grt;
	}
	public void set_grt(Group s) {
		grt=s;
	}
	@FXML
	private MenuItem menuitem1, menuitem2, menuitem3;
	private ObjectInputStream ois;
	private double[] upper_X;
	private AnchorPane demo = new AnchorPane();
	static int zre=0;
	public void set_zre() {
		zre=0;
		ois = null;
	}
	public static int get_zre() {
		return zre;
	}
	private double[] upper_Y;
	int p;
	int index=0;
	private Player[] g;
	int end=0;
	public grid() {
	}
	public int get() {
		return end;
	}
	public void set_end() {
		end=1;
	}
	public double[] X() {
		return upper_X;
	}
	public double[] Y() {
		return upper_Y;
	}
	public void set_list(Player[] o) {
		g=o;
	}
	public Player[] get_list() {
		return g;
	}
	public void delete(Player s) {
		Player[] temp=new Player[g.length-1];
		int j=0;
		for(int i=0;i<g.length;i++) {
			if(g[i]!=s) {
				temp[j]=g[i];
				j++;
			}
		}
		g=temp;
	}
	public void Read() throws IOException, ClassNotFoundException {
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream("./src/application/file.bin"));
		Cell[][] cell = (Cell[][]) ois.readObject();
//		Player[] p = (Player[]) ois.readObject();
		System.out.println(cell+" "+p);
		ois.close();
	}
	
//	@FXML
//	public void HandleUndo(ActionEvent me) throws Exception {
//		try {
//		if(me.getTarget()==buttonundo) {
//			zre=1;
//			System.out.println(stk.Peek());
//			System.out.println("yes undo");
//		}
//		}
//		catch(Exception e) {
//			System.out.println(e.getMessage());
//		}
//	}
	
	@FXML
	public void HandleStartAgain(ActionEvent event) throws Exception {
		if(event.getTarget()==menuitem1) {
			Stage stage = (Stage) buttonmenu.getScene().getWindow();
			grid g = new grid();
			g.start(stage);
		}
	}
	@FXML
	public void HandleMainMenu(ActionEvent event) throws Exception {
		if(event.getTarget()==menuitem2) {
			Stage stage = (Stage) game.getScene().getWindow();
			AnchorPane root = FXMLLoader.load(getClass().getResource("mainpage.fxml"));
			Scene sc = new Scene(root);
			stage.setScene(sc);
			stage.show();
		}
	}
	
	@FXML
	public void HandleExit(ActionEvent event) throws IOException {
		if(event.getTarget()==menuitem3) {
			System.exit(0);
		}
	}
	public Group Make_Grid(String s,String color) {
		int wq=0;
		if(color.equals("green")) {
			wq=1;//green
		}
		else if(color.equals("yellow")) {
			wq=2;//yellow
		}
		else if(color.equals("blue")) {
			wq=3;//blue
		}
		else if(color.equals("red")) {
			wq=4;//red
		}
		else if(color.equals("pink")) {
			wq=5;//pink
		}
		else if(color.equals("orange")) {
			wq=6;//orange
		}
		else if(color.equals("violet")) {
			wq=7;//violet
		}
		else if(color.equals("brown")) {
			wq=8;//brown
		}
		String[] top=s.split("x");
		int row=Integer.parseInt(top[0]);//Number of rows
		int col=Integer.parseInt(top[1]);//number of columns
		Group root=new Group();//Top level group
		int dist;
		int left_diff;
		int up_diff;
		if(row==9) {
			dist=50;
			left_diff=50;
			up_diff=50;
		}
		else {
			dist=40;
			left_diff=40;
			up_diff=40;
		}
		int X=40;
		int Y=40;
		double[] b1=new double[col+1];
		double[] b2=new double[row+1];
		b1[0]=X;
		b2[0]=Y;
		for(int j=0;j<row;j++) {
			Group bottom_level=new Group();//Bottom level group for the number of columns
			for(int i=0;i<col;i++) {
				Rectangle rectangle = new Rectangle();
				rectangle.setX(X);
				rectangle.setY(Y);
				rectangle.setWidth(dist);
				rectangle.setHeight(dist);
				if(wq==1) {
					rectangle.setStroke(Color.valueOf("00ff00"));//green
				}
				else if(wq==2) {
					rectangle.setStroke(Color.valueOf("feff00"));//yellow
				}
				else if(wq==3) {
					rectangle.setStroke(Color.valueOf("0049ff"));//blue
				}
				else if(wq==4) {
					rectangle.setStroke(Color.valueOf("ff0000"));//red
				}
				else if(wq==5) {
					rectangle.setStroke(Color.valueOf("ff00bf"));//pink
				}
				else if(wq==6) {
					rectangle.setStroke(Color.valueOf("ff9c00"));//orange
				}
				else if(wq==7) {
					rectangle.setStroke(Color.valueOf("ae00ff"));//violet
				}
				else {
					rectangle.setStroke(Color.valueOf("a73d0c"));//brown
				}
				rectangle.setFill(Color.TRANSPARENT);
				bottom_level.getChildren().add(rectangle);
				X=X+left_diff;
				b1[i+1]=X;
			}
			X=40;
			Y=Y+up_diff;
			b2[j+1]=Y;
			root.getChildren().add(bottom_level);
		}
		double X1=30;
		double Y1=30;
		double dist_x=dist;
		double dist_y=dist;
		int s1=0;
		if(col%2==0) {
			s1=0;
		}
		else {
			s1=1;
		}
		int s2=0;
		if(row%2==0) {
			s2=0;
		}
		else {
			s2=1;
		}
		double d_p=0;
		if(col==6) {
			d_p=3;
		}
		else {
			d_p=1;
		}
		double[] e1=new double[col+1];
		e1[0]=X1;
		double[] e2=new double[row+1];
		e2[0]=Y1;
		for(int j=0;j<row;j++) {
			Group bottom_level=new Group();//Bottom level group for the number of columns
			for(int i=0;i<col;i++) {
				Rectangle rectangle = new Rectangle();
				rectangle.setX(X1);
				rectangle.setY(Y1);
				rectangle.setWidth(dist_x);
				rectangle.setHeight(dist_y);
				if(wq==1) {
					rectangle.setStroke(Color.valueOf("00ff00"));//green
				}
				else if(wq==2) {
					rectangle.setStroke(Color.valueOf("feff00"));//yellow
				}
				else if(wq==3) {
					rectangle.setStroke(Color.valueOf("0049ff"));//blue
				}
				else if(wq==4) {
					rectangle.setStroke(Color.valueOf("ff0000"));//red
				}
				else if(wq==5) {
					rectangle.setStroke(Color.valueOf("ff00bf"));//pink
				}
				else if(wq==6) {
					rectangle.setStroke(Color.valueOf("ff9c00"));//orange
				}
				else if(wq==7) {
					rectangle.setStroke(Color.valueOf("ae00ff"));//violet
				}
				else {
					rectangle.setStroke(Color.valueOf("a73d0c"));//brown
				}
				rectangle.setFill(Color.TRANSPARENT);
				bottom_level.getChildren().add(rectangle);
				X1=X1+dist_x;
				if(s1==0) {
					if(i<col/2) {
						dist_x=dist_x+d_p;
					}
					else {
					dist_x=dist_x-d_p;
					}
				}
				else {
					if(i<(col-1)/2) {
						dist_x=dist_x+d_p;
					}
					else {
						dist_x=dist_x-d_p;
					}
				}
				if(j==0) {
				e1[i+1]=X1;
				}
			}
			X1=30;
			if(s2==0) {
				if(j<row/2 && j!=0) {
					Y1=Y1+dist_y;
				}
				else if(j==0) {
					Y1=Y1+dist_y;
				}
				else {
					Y1=Y1+dist_y-d_p;
				}
			}
			else {
				if(j<(row-1)/2 && j!=0) {
					Y1=Y1+dist_y;
				}
				else if(j==0) {
					Y1=Y1+dist_y;
				}
				else {
					Y1=Y1+dist_y;
				}
				e2[j+1]=Y1;
			}
			double t=0;
			if(row==9) {
				t=1;
			}
			else {
				t=0.35;
			}
			if(s2==0) {
				if(j<row/2) {
					dist_y=dist_y+d_p;
				}
				else {
					dist_y=dist_y-d_p;
				}
			}
			else {
				if(j<(row-1)/2-1) {
					dist_y=dist_y+d_p-t;
				}
				else if(j>(row-1)/2){
					dist_y=dist_y-d_p-t;
				}
			}
			root.getChildren().add(bottom_level);
		}
		for(int j=0;j<row+1;j++) {
		for(int i=0;i<col+1;i++) {
			Line line=new Line();
			line.setStartX(b1[i]);
			line.setStartY(b2[j]);
			line.setEndX(e1[i]);
			line.setEndY(e2[j]);
			if(wq==1) {
				line.setStroke(Color.valueOf("00ff00"));//green
			}
			else if(wq==2) {
				line.setStroke(Color.valueOf("feff00"));//yellow
			}
			else if(wq==3) {
				line.setStroke(Color.valueOf("0049ff"));//blue
			}
			else if(wq==4) {
				line.setStroke(Color.valueOf("ff0000"));//red
			}
			else if(wq==5) {
				line.setStroke(Color.valueOf("ff00bf"));//pink
			}
			else if(wq==6) {
				line.setStroke(Color.valueOf("ff9c00"));//orange
			}
			else if(wq==7) {
				line.setStroke(Color.valueOf("ae00ff"));//violet
			}
			else {
				line.setStroke(Color.valueOf("a73d0c"));//brown
			}
			root.getChildren().add(line);
		}}
		upper_X=e1;
		upper_Y=e2;
		return root;
	}
	public double[] getX() {
		return upper_X;
	}
	public double[] getY() {
		return upper_Y;
	}
	public static void main(String[] args) {
		launch(args);
	}
	public void set_Player(int d) {
		index=d;
	}
	public int get_Player() {
		return index++;
	}
	private Pane createShadowPane() {
        Pane shadowPane = new Pane();
        // a "real" app would do this in a CSS stylesheet.
        shadowPane.setStyle(
                "-fx-background-color: white;" +
                "-fx-effect: dropshadow(gaussian, red, " + 50 + ", 0, 0, 0);" +
                "-fx-background-insets: " + 50 + ";"
        );

        Rectangle innerRect = new Rectangle();
        Rectangle outerRect = new Rectangle();
        shadowPane.layoutBoundsProperty().addListener(
                (observable, oldBounds, newBounds) -> {
                    innerRect.relocate(
                            newBounds.getMinX() + 50,
                            newBounds.getMinY() + 50
                    );
                    innerRect.setWidth(newBounds.getWidth() - 50 * 2);
                    innerRect.setHeight(newBounds.getHeight() - 50 * 2);

                    outerRect.setWidth(newBounds.getWidth());
                    outerRect.setHeight(newBounds.getHeight());

                    Shape clip = Shape.subtract(outerRect, innerRect);
                    shadowPane.setClip(clip);
                }
        );

        return shadowPane;
    }
	@Override
	public void start(Stage stage) throws Exception {
		try {
			game = FXMLLoader.load(getClass().getResource("game.fxml"));
		//Player part
		String musicFile = "./src/application/MDHR_LOGO_STING.wav";
		Media sound = new Media(new File(musicFile).toURI().toString());
		MediaPlayer mediaPlayer = new MediaPlayer(sound);
		mediaPlayer.play();
		Scanner input = new Scanner(new File("./src/application/info.txt"));
		int number=Integer.parseInt(input.nextLine());
		String p = input.nextLine();
		Player[] Player=new Player[number];
		String[] arr = input.nextLine().split(" ");
		for(int i=0; i<number; i++) {
			Player[i] = new Player(arr[i]);
		}
		//grid part
		grid t=new grid();
		t.set_list(Player);
		String[] temp=p.split("x");
		int row=Integer.parseInt(temp[0]);
		int col=Integer.parseInt(temp[1]);
		//
		int diff;
		if(row==9) {
			diff=50;
		}
		else {
			diff=40;
		}
		Group bottom=t.Make_Grid(p,t.get_list()[0].get_color());
		t.set_Player(0);
		Group root=new Group();
		root.getChildren().add(bottom);
		double[] X1=t.X();
		double[] Y1=t.Y();
		Cell[][] cell=new Cell[Y1.length][X1.length];
		for(int i=0;i<(Y1.length);i++) {
			for(int j=0;j<(X1.length);j++) {
				cell[i][j]=new Cell();
			}
		}
    	for(int i=0;i<(Y1.length);i++) {
    		for(int j=0;j<(X1.length);j++) {
    			cell[i][j].setX(X1[j]);
    			cell[i][j].setY(Y1[i]);
    			cell[i][j].set_radius(row);
    			if((i==0 && j==0) || (i==Y1.length-2 && j==0) || (i==0 && j==X1.length-2) || (i==Y1.length-2 && j==X1.length-2)) {
    				cell[i][j].set_mass(1);
    			}
    			else if (i==0 && j!=0 && j!=X1.length-2) {
    				cell[i][j].set_mass(2);
    			}
    			else if (j==0 && i!=0 && i!=Y1.length-2) {
    				cell[i][j].set_mass(2);
    			}
    			else if (i==Y1.length-2 && j!=0 && j!=X1.length-2) {
    				cell[i][j].set_mass(2);
    			}
    			else if (j==X1.length-2 && i!=0 && i!=Y1.length-2) {
    				cell[i][j].set_mass(2);
    			}
    			else {
    				if(i!=Y1.length-1 && j!=X1.length-1) {
    				cell[i][j].set_mass(3);}
    			}
    		}
    	}
    	StackPane stackPane = new StackPane(createShadowPane());
    	stackPane.setStyle(
                "-fx-background-color: rgba(255, 255, 255, 0.5);" +
                "-fx-background-insets: " + 50 + ";"
        );
    	t.set_root(root);
    	Button btn = (Button) game.getChildren().get(0);
    	btn.setOnAction(new EventHandler<ActionEvent> () {
			@Override
			public void handle(ActionEvent event) {
				try {
					Read();
				} catch (ClassNotFoundException | IOException e) {
					System.out.println("error "+e.getMessage());
				}
			}
    		
    	});
        root.setOnMouseReleased(new EventHandler<MouseEvent> () {
        	@Override
            public void handle(MouseEvent me) {
            	double x=me.getSceneX();
            	double y=me.getSceneY();
        		String musicFile = "./src/application/click.mp3";
        		Media sound = new Media(new File(musicFile).toURI().toString());
        		MediaPlayer mediaPlayer = new MediaPlayer(sound);
        		mediaPlayer.play();
            	//matrix array's start
            	double u1=0;
            	double u2=0;
            	double w1=0;
            	double w2=0;
            	int index1=0;
            	int index2=0;
            	for(int i=0;i<X1.length;i++) {
            		if(x>X1[i] && x<X1[i+1]) {
            			u1=X1[i];
            			u2=X1[i+1];
            			index1=i;
            		}
            	}
            	for(int i=0;i<Y1.length;i++) {
            		if(y>Y1[i] && y<Y1[i+1]) {
            			w1=Y1[i];
            			w2=Y1[i+1];
            			index2=i;
            		}
            	}
            	int w=cell[index2][index1].get_count();
            	//changing the color of grid
            	Color c=null;
            	int y1=t.get_Player();
            	Group bottom=new Group();
            	if(y1==0) {
            		bottom=t.Make_Grid(p,t.get_list()[1].get_color());
            		if(t.get_list()[y1].get_color().equals("blue")) {
            			c=Color.valueOf("0049ff");//blue
            		}
            		else if(t.get_list()[y1].get_color().equals("red")) {
            			c=Color.valueOf("ff0000");//red
            		}
            		else if(t.get_list()[y1].get_color().equals("green")) {
            			c=Color.valueOf("00ff00");//green
            		}
            		else if(t.get_list()[y1].get_color().equals("yellow")) {
            			c=Color.valueOf("feff00");//yellow
            		}
            		else if(t.get_list()[y1].get_color().equals("brown")) {
            			c=Color.valueOf("a73d0c");//brown
            		}
            		else if(t.get_list()[y1].get_color().equals("violet")) {
            			c=Color.valueOf("ae00ff");//violet
            		}
            		else if(t.get_list()[y1].get_color().equals("pink")) {
            			c=Color.valueOf("ff00bf");//pink
            		}
            		else{
            			c=Color.valueOf("ff9c00");//orange
            		}
            	}
            	if (y1+1==t.get_list().length) {
            		bottom=t.Make_Grid(p,t.get_list()[0].get_color());
            		t.set_Player(0);
            		if(t.get_list()[y1].get_color().equals("blue")) {
            			c=Color.valueOf("0049ff");//blue
            		}
            		else if(t.get_list()[y1].get_color().equals("red")) {
            			c=Color.valueOf("ff0000");//red
            		}
            		else if(t.get_list()[y1].get_color().equals("green")) {
            			c=Color.valueOf("00ff00");//green
            		}
            		else if(t.get_list()[y1].get_color().equals("yellow")) {
            			c=Color.valueOf("feff00");//yellow
            		}
            		else if(t.get_list()[y1].get_color().equals("brown")) {
            			c=Color.valueOf("a73d0c");//brown
            		}
            		else if(t.get_list()[y1].get_color().equals("violet")) {
            			c=Color.valueOf("ae00ff");//violet
            		}
            		else if(t.get_list()[y1].get_color().equals("pink")) {
            			c=Color.valueOf("ff00bf");//pink
            		}
            		else{
            			c=Color.valueOf("ff9c00");//orange
            		}
            	}
            	if(y1+1!=t.get_list().length && y1!=0){
            		bottom=t.Make_Grid(p,t.get_list()[y1+1].get_color());
            		if(t.get_list()[y1].get_color().equals("blue")) {
            			c=Color.valueOf("0049ff");//blue
            		}
            		else if(t.get_list()[y1].get_color().equals("red")) {
            			c=Color.valueOf("ff0000");//red
            		}
            		else if(t.get_list()[y1].get_color().equals("green")) {
            			c=Color.valueOf("00ff00");//green
            		}
            		else if(t.get_list()[y1].get_color().equals("yellow")) {
            			c=Color.valueOf("feff00");//yellow
            		}
            		else if(t.get_list()[y1].get_color().equals("brown")) {
            			c=Color.valueOf("a73d0c");//brown
            		}
            		else if(t.get_list()[y1].get_color().equals("violet")) {
            			c=Color.valueOf("ae00ff");//violet
            		}
            		else if(t.get_list()[y1].get_color().equals("pink")) {
            			c=Color.valueOf("ff00bf");//pink
            		}
            		else{
            			c=Color.valueOf("ff9c00");//orange
            		}
            	}
            	int e1=0;
            	try {
					cell[index2][index1].add(cell, u1, u2, w1, w2,index2,index1,root,0,0,0,0,0,0,0,c,t.get_list()[y1],t.get_list());
					String d="";
					for(int i=0;i<t.get_list().length;i++) {
						if(t.get_list()[i].get_check() && t.get_list()[i].get_count()==0) {
							d=d+i;
						}
					}
					Player[] f=t.get_list();
					for(int i=0;i<d.length();i++) {
						t.delete(f[Character.getNumericValue(d.charAt(i))]);
					}
					if(t.get_list().length==1) {
						int s=0;
						for(int i=0;i<Player.length;i++) {
							if(t.get_list()[0]==Player[i]) {
								s=i;
							}
						}
						Text text=new Text();
						String ff="Player  "+(s+1)+" "+t.get_list()[0].get_color()+"  wins";
						text.setText(ff);
						text.setX(80);
						text.setY(80);
						text.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 20));
						stackPane.getChildren().add(text);
						Scene scene1=new Scene(stackPane,40*2+col*diff+50,40*2+row*diff+50,Color.TRANSPARENT);
						stage.setScene(scene1);
						t.set_end();
					}
					else if(t.get_list().length!=1){
						String r="";
						if(c.equals(Color.valueOf("ff0000"))) {r="red";}else if(c.equals(Color.valueOf("0049ff"))){r="blue";}else if(c.equals(Color.valueOf("ff00bf"))){r="pink";}else if(c.equals(Color.valueOf("00ff00"))){r="green";}
						else if(c.equals(Color.valueOf("feff00"))){r="yellow";}else if(c.equals(Color.valueOf("a73d0c"))){r="brown";}else if(c.equals(Color.valueOf("ae00ff"))){r="violet";}else{r="orange";}
						for(int i=0;i<t.get_list().length;i++) {
							if(r.equals(t.get_list()[i].get_color())) {
								if(i==t.get_list().length-1) {
									bottom=t.Make_Grid(p,t.get_list()[0].get_color());
									t.set_Player(0);
								}
								else {
									bottom=t.Make_Grid(p,t.get_list()[i+1].get_color());
									t.set_Player(i+1);
								}
							}
						}
					}
					e1=cell[index2][index1].get_count();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
            	catch(Exception e) {
            		System.out.println(e.getMessage());
            	}
            	if(w!=e1) {
            		if(w<e1 || w!=3) {
            			root.getChildren().set(0,bottom);
            		}
            		else if(w==3) {
            			root.getChildren().set(0,bottom);
            		}
            		else {
            			t.set_Player(y1);
            		}
            	}
            	else if(w==e1){
            		if(cell[index2][index1].get_colour()!=c) {
            			t.set_Player(y1);
            		}
            		else {
            			root.getChildren().set(0,bottom);
            		}
            	}
            }
            });
    	
        
        Button btn1 = (Button) game.getChildren().get(0);
        MenuButton btn2 = (MenuButton) game.getChildren().get(1);
        if(col==6) {
        	btn1.setTranslateY(col-30);
            btn2.setTranslateY(col-30);
            btn2.setTranslateX(row-30);
        }
        else if(col==10) {
        	btn1.setTranslateY(40*2+col+diff);
            btn2.setTranslateY(40*2+col+diff);
            btn2.setTranslateX(40+row+diff);
        }
        game.getChildren().add(t.get_root());
        Scene scene=new Scene(game,40*2+col*diff,40*2+row*diff+50);
		stage.setTitle("Grid");
		stage.setScene(scene);
		stage.show();}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
