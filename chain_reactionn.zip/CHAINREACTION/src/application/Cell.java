package application;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Shape3D;
import javafx.scene.shape.Sphere;
import javafx.scene.transform.Rotate;
import javafx.util.Duration;

class Cell implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	double x;
	private double y;
	private int critical_mass=0;
	private int count=0;
	private int radius;
	private Group spheres;
	private Color cl=null;
	public void set_colour(Color d) {
		cl=d;
	}
	public Color get_colour() {
		return this.cl;
	}
	public void set_spheres() {
		spheres=new Group();
	}
	public Cell() {
		spheres =new Group();
	}
	public void setX(double a) {
		this.x=a;
	}
	public void setY(double a) {
		this.y=a;
	}
	public void set_mass(int a) {
		this.critical_mass=a;
	}
	public void set_count(int i) {
		count=i;
	}
	public double getX() {
		return this.x;
	}
	public double getY() {
		return this.y;
	}
	public int get_mass() {
		return this.critical_mass;
	}
	public int get_count() {
		return count;
	}
	public void set_radius(int a) {
		if(a==9) {
			this.radius=10;
		}
		else {
			this.radius=8;
		}
	}
	public int get_radius() {
		return this.radius;
	}
	
	public void Write(Cell[][] cell) throws FileNotFoundException, IOException {
		try {
		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("./src/application/file.bin"));
		oos.writeObject(cell);
//		oos.writeObject(p);
		oos.close();
		}
		catch(Exception e) {
			System.out.println("error "+e.getMessage());
		}
	}
	
	public Sphere sphere1(double x1,double x2,double y1,double y2,Color c) {
		Sphere sphere1 = new Sphere();
		sphere1.setRadius(this.get_radius());
		sphere1.setTranslateX((x1+x2)/2);
		sphere1.setTranslateY((y1+y2)/2);
		sphere1.setMaterial(new PhongMaterial(c));
		return sphere1;
	}
	public Sphere sphere2(double x1,double x2,double y1,double y2,Color c) {
		Sphere sphere2 = new Sphere();
		sphere2.setRadius(this.get_radius());
		sphere2.setTranslateX((x1+x2)/2+10);
		sphere2.setTranslateY((y1+y2)/2+9);
		sphere2.setMaterial(new PhongMaterial(c));
		return sphere2;
	}
	public Sphere sphere3(double x1,double x2,double y1,double y2,Color c) {
		Sphere sphere3 = new Sphere();
		sphere3.setRadius(this.get_radius());
		sphere3.setTranslateX((x1+x2)/2+10);
		sphere3.setTranslateY((y1+y2)/2-6);
		sphere3.setMaterial(new PhongMaterial(c));
		return sphere3;
	}
	public void add(Cell[][] cell,double x1,double x2,double y1,double y2,int index2,int index1,Group root,int e,int r1,int l1,int u1,int d1,double xm,double ym,Color c,Player p,Player[] p1) throws InterruptedException {
		try {
			Write(cell);
		} catch (FileNotFoundException e1) {
			System.out.println(e1.getMessage());
		} catch (IOException e1) {
			System.out.println(e1.getMessage());
		}
		int mass=this.critical_mass;
		int count=cell[index2][index1].count;
		RotateTransition r = new RotateTransition(Duration.seconds(5),this.spheres);
		r.setByAngle(360);
		r.setAxis(Rotate.Z_AXIS);
		r.setInterpolator(Interpolator.LINEAR);
		r.setCycleCount(Timeline.INDEFINITE);
//		r.play();
		if(count<mass) {
			if(count==0) {
				p.inc_count();
				if(p.get_check()==false) {
					p.check(true);
				}
				Sphere sphere1 = this.sphere1(x1, x2, y1, y2,c);
				this.set_colour(c);
				if(e==1) {
					r.pause();
					if(r1==1) {
						sphere1=new Sphere();
						sphere1.setRadius(this.get_radius());
						sphere1.setTranslateX((x1+x2)/2);
						sphere1.setTranslateY((y1+y2)/2);
						sphere1.setMaterial(new PhongMaterial(c));
						TranslateTransition t = new TranslateTransition();
						t.setDuration(Duration.millis(300)); 
						t.setNode(sphere1);
						t.setFromX(xm);
					    t.setToX((x1+x2)/2);
						t.play();
					}
					else if(l1==1) {
						sphere1=new Sphere();
						sphere1.setRadius(this.get_radius());
						sphere1.setTranslateX((x1+x2)/2);
						sphere1.setTranslateY((y1+y2)/2);
						sphere1.setMaterial(new PhongMaterial(c));
						TranslateTransition t = new TranslateTransition();
					    t.setDuration(Duration.millis(300)); 
						t.setNode(sphere1);
						t.setFromX(xm);
					    t.setToX((x1+x2)/2);
						t.play();
					}
					else if(u1==1) {
						sphere1=new Sphere();
						sphere1.setRadius(this.get_radius());
						sphere1.setTranslateX((x1+x2)/2);
						sphere1.setTranslateY((y1+y2)/2);
						sphere1.setMaterial(new PhongMaterial(c));
						TranslateTransition t = new TranslateTransition();
					    t.setDuration(Duration.millis(300)); 
						t.setNode(sphere1);
						t.setFromY(ym);
					    t.setToY((y1+y2)/2);
						t.play();
					}
					else {
						sphere1=new Sphere();
						sphere1.setRadius(this.get_radius());
						sphere1.setTranslateX((x1+x2)/2);
						sphere1.setTranslateY((y1+y2)/2);
						sphere1.setMaterial(new PhongMaterial(c));
						TranslateTransition t = new TranslateTransition();
						t.setDuration(Duration.millis(300)); 
						t.setNode(sphere1);
						t.setFromY(ym);
					    t.setToY((y1+y2)/2);
						t.play();
					}
				}
				this.spheres.getChildren().add(sphere1);
    			root.getChildren().add(this.spheres);
				this.set_count(1);
			}
			else if(count==1 && (c.equals(this.get_colour()) || e==1)) {
				Group n=this.spheres;
				p.inc_count();
				if(!c.equals(this.get_colour())) {
					Color q=this.get_colour();
					Color q1=null;
					for(int i=0;i<p1.length;i++) {
						if(p1[i].get_color().equals("blue")) {
	            			q1=Color.valueOf("0049ff");//blue
	            		}
	            		else if(p1[i].get_color().equals("red")) {
	            			q1=Color.valueOf("ff0000");//red
	            		}
	            		else if(p1[i].get_color().equals("green")) {
	            			q1=Color.valueOf("00ff00");//green
	            		}
	            		else if(p1[i].get_color().equals("yellow")) {
	            			q1=Color.valueOf("feff00");//yellow
	            		}
	            		else if(p1[i].get_color().equals("brown")) {
	            			q1=Color.valueOf("a73d0c");
	            		}
	            		else if(p1[i].get_color().equals("violet")) {
	            			q1=Color.valueOf("ae00ff");//violet
	            		}
	            		else if(p1[i].get_color().equals("pink")) {
	            			q1=Color.valueOf("ff00bf");//pink
	            		}
	            		else{
	            			q1=Color.valueOf("ff9c00");//orange
	            		}
						if(q.equals(q1)) {
							p1[i].set_count(p1[i].get_count()-1);
							break;
						}
					}
					p.set_count(p.get_count()+1);
					for(int i=0;i<n.getChildren().size();i++) {
						((Shape3D) n.getChildren().get(i)).setMaterial(new PhongMaterial(c));
					}
					this.set_colour(c);
				}
				Sphere sphere2 = this.sphere2(x1, x2, y1, y2,c);
				if(e==1) {
					if(r1==1) {
						r.pause();
						sphere2=new Sphere();
						sphere2.setRadius(this.get_radius());
						sphere2.setTranslateX((x1+x2)/2+10);
						sphere2.setTranslateY((y1+y2)/2+8);
						sphere2.setMaterial(new PhongMaterial(c));
						TranslateTransition t = new TranslateTransition();
						t.setDuration(Duration.millis(300)); 
						t.setNode(sphere2);
						t.setFromX(xm);
					    t.setToX((x1+x2)/2+10);
						t.play();
					}
					else if(l1==1) {
						sphere2=new Sphere();
						sphere2.setRadius(this.get_radius());
						sphere2.setTranslateX((x1+x2)/2+10);
						sphere2.setTranslateY((y1+y2)/2+8);
						sphere2.setMaterial(new PhongMaterial(c));
						TranslateTransition t = new TranslateTransition();
					    t.setDuration(Duration.millis(300)); 
						t.setNode(sphere2);
						t.setFromX(xm);
					    t.setToX((x1+x2)/2+10);
						t.play();
					}
					else if(u1==1) {
						r.pause();
						sphere2=new Sphere();
						sphere2.setRadius(this.get_radius());
						sphere2.setTranslateX((x1+x2)/2+10);
						sphere2.setTranslateY((y1+y2)/2+9);
						sphere2.setMaterial(new PhongMaterial(c));
						TranslateTransition t = new TranslateTransition();
					    t.setDuration(Duration.millis(300)); 
						t.setNode(sphere2);
						t.setFromY(ym);
					    t.setToY((y1+y2)/2+6);
						t.play();
					}
					else {
						sphere2=new Sphere();
						sphere2.setRadius(this.get_radius());
						sphere2.setTranslateX((x1+x2)/2+10);
						sphere2.setTranslateY((y1+y2)/2+9);
						sphere2.setMaterial(new PhongMaterial(c));
						TranslateTransition t = new TranslateTransition();
						t.setDuration(Duration.millis(300)); 
						t.setNode(sphere2);
						t.setFromY(ym);
					    t.setToY((y1+y2)/2+6);
						t.play();
					}
				}
				n.getChildren().add(sphere2);
				this.set_count(2);
				this.spheres=n;
			}
			else if(count==2 && (c.equals(this.get_colour()) || e==1)) {
				Group n=this.spheres;
				p.inc_count();
				if(!c.equals(this.get_colour())) {
					Color q=this.get_colour();
					Color q1=null;
					for(int i=0;i<p1.length;i++) {
						if(p1[i].get_color().equals("blue")) {
	            			q1=Color.valueOf("0049ff");//blue
	            		}
	            		else if(p1[i].get_color().equals("red")) {
	            			q1=Color.valueOf("ff0000");//red
	            		}
	            		else if(p1[i].get_color().equals("green")) {
	            			q1=Color.valueOf("00ff00");//green
	            		}
	            		else if(p1[i].get_color().equals("yellow")) {
	            			q1=Color.valueOf("feff00");//yellow
	            		}
	            		else if(p1[i].get_color().equals("brown")) {
	            			q1=Color.valueOf("a73d0c");//brown
	            		}
	            		else if(p1[i].get_color().equals("violet")) {
	            			q1=Color.valueOf("ae00ff");//violet
	            		}
	            		else if(p1[i].get_color().equals("pink")) {
	            			q1=Color.valueOf("ff00bf");//pink
	            		}
	            		else{
	            			q1=Color.valueOf("ff9c00");//orange
	            		}
						if(q.equals(q1)) {
							p1[i].set_count(p1[i].get_count()-2);
							break;
						}
					}
					p.set_count(p.get_count()+2);
					for(int i=0;i<n.getChildren().size();i++) {
						((Shape3D) n.getChildren().get(i)).setMaterial(new PhongMaterial(c));
					}
					this.set_colour(c);
				}
				Sphere sphere3 = this.sphere3(x1, x2, y1, y2,c);
				if(e==1) {
					if(r1==1) {
						r.pause();
						sphere3=new Sphere();
						sphere3.setRadius(this.get_radius());
						sphere3.setTranslateX((x1+x2)/2+10);
						sphere3.setTranslateY((y1+y2)/2-6);
						sphere3.setMaterial(new PhongMaterial(c));
						TranslateTransition t = new TranslateTransition();
						t.setDuration(Duration.millis(300)); 
						t.setNode(sphere3);
						t.setFromX(xm);
					    t.setToX((x1+x2)/2+10);
						t.play();
					}
					else if(l1==1) {
						sphere3=new Sphere();
						sphere3.setRadius(this.get_radius());
						sphere3.setTranslateX((x1+x2)/2+10);
						sphere3.setTranslateY((y1+y2)/2-6);
						sphere3.setMaterial(new PhongMaterial(c));
						TranslateTransition t = new TranslateTransition();
					    t.setDuration(Duration.millis(300)); 
						t.setNode(sphere3);
						t.setFromX(xm);
					    t.setToX((x1+x2)/2+10);
						t.play();
					}
					else if(u1==1) {
						sphere3=new Sphere();
						sphere3.setRadius(this.get_radius());
						sphere3.setTranslateX((x1+x2)/2+10);
						sphere3.setTranslateY((y1+y2)/2-6);
						sphere3.setMaterial(new PhongMaterial(c));
						TranslateTransition t = new TranslateTransition();
					    t.setDuration(Duration.millis(300)); 
						t.setNode(sphere3);
						t.setFromY(ym);
					    t.setToY((y1+y2)/2-6);
						t.play();
					}
					else {
						sphere3=new Sphere();
						sphere3.setRadius(this.get_radius());
						sphere3.setTranslateX((x1+x2)/2+10);
						sphere3.setTranslateY((y1+y2)/2-6);
						sphere3.setMaterial(new PhongMaterial(c));
						TranslateTransition t = new TranslateTransition(); 
						t.setDuration(Duration.millis(300)); 
						t.setNode(sphere3);
						t.setFromY(ym);
					    t.setToY((y1+y2)/2-6);
						t.play();
					}
				}
				n.getChildren().add(sphere3);
				this.set_count(3);
				this.spheres=n;
			}
		}
		else {
			boolean b=c.equals(this.get_colour());
			if(b || e==1) {
			root.getChildren().remove(this.spheres);
			this.set_count(0);
			this.set_spheres();
			if(b) {
				if(mass==3) {
					p.set_count(p.get_count()-3);
				}
				else if(mass==2) {
					p.set_count(p.get_count()-2);
				}
				else if(mass==1) {
					p.set_count(p.get_count()-1);
				}
			}
			else {
				Color q1=null;
				for(int i=0;i<p1.length;i++) {
					if(p1[i].get_color().equals("blue")) {
            			q1=Color.valueOf("0049ff");//blue
            		}
            		else if(p1[i].get_color().equals("red")) {
            			q1=Color.valueOf("ff0000");//red
            		}
            		else if(p1[i].get_color().equals("green")) {
            			q1=Color.valueOf("00ff00");//green
            		}
            		else if(p1[i].get_color().equals("yellow")) {
            			q1=Color.valueOf("feff00");//yellow
            		}
            		else if(p1[i].get_color().equals("brown")) {
            			q1=Color.valueOf("a73d0c");
            		}
            		else if(p1[i].get_color().equals("violet")) {
            			q1=Color.valueOf("ae00ff");//violet
            		}
            		else if(p1[i].get_color().equals("pink")) {
            			q1=Color.valueOf("ff00bf");//pink
            		}
            		else{
            			q1=Color.valueOf("ff9c00");//orange
            		}
					if(this.get_colour().equals(q1)) {
						if(mass==3) {
							p1[i].set_count(p1[i].get_count()-3);
						}
						else if(mass==2) {
							p1[i].set_count(p1[i].get_count()-2);
						}
						else if(mass==1) {
							p1[i].set_count(p1[i].get_count()-1);
						}
						break;
					}
				}
			}
			this.set_colour(null);
			this.explode(cell,x1,x2,y1,y2,index2,index1,root,c,p,p1);}
			
		}
		r.play();
	}
	@SuppressWarnings("restriction")
	public void explode(Cell[][] cell,double x1,double x2,double y1,double y2,int index2,int index1,Group root,Color c,Player p,Player[] p1) throws InterruptedException {
		int row=cell.length-2;
		int col=cell[0].length-2;
		if(index2==0 && index1==0) {
			Cell R1=cell[index2][index1+2];
			Cell D1=cell[index2+2][index1];
			cell[index2][index1+1].add(cell, x2,R1.getX(), y1, y2, index2, index1+1,root,1,1,0,0,0,(x1+x2)/2,(y1+y2)/2,c,p,p1);
			cell[index2+1][index1].add(cell, x1, x2, y2,D1.getY() , index2+1, index1,root,1,0,0,0,1,(x1+x2)/2,(y1+y2)/2,c,p,p1);
		}
		else if(index2==0 && index1==col) {
			Cell L1=cell[index2][index1-1];
			Cell D1=cell[index2+2][index1];
			cell[index2][index1-1].add(cell,L1.getX(),x1, y1, y2, index2, index1-1,root,1,0,1,0,0,(x1+x2)/2,(y1+y2)/2,c,p,p1);
			cell[index2+1][index1].add(cell, x1, x2, y2,D1.getY() , index2+1, index1,root,1,0,0,0,1,(x1+x2)/2,(y1+y2)/2,c,p,p1);
		}
		else if(index2==row && index1==0) {
			Cell R1=cell[index2][index1+2];
			Cell U1=cell[index2-1][index1];
			cell[index2][index1+1].add(cell, x2,R1.getX(), y1, y2, index2, index1+1,root,1,1,0,0,0,(x1+x2)/2,(y1+y2)/2,c,p,p1);
			cell[index2-1][index1].add(cell, x1, x2,U1.getY(),y1, index2-1, index1,root,1,0,0,1,0,(x1+x2)/2,(y1+y2)/2,c,p,p1);
		}
		else if(index2==row && index1==col) {
			Cell L1=cell[index2][index1-1];
			Cell U1=cell[index2-1][index1];
			cell[index2][index1-1].add(cell,L1.getX(),x1, y1, y2, index2, index1-1,root,1,0,1,0,0,(x1+x2)/2,(y1+y2)/2,c,p,p1);
			cell[index2-1][index1].add(cell, x1, x2,U1.getY(),y1, index2-1, index1,root,1,0,0,1,0,(x1+x2)/2,(y1+y2)/2,c,p,p1);
		}
		else if(index2==0 && index1!=0 && index1!=col) {
			Cell L1=cell[index2][index1-1];
			Cell D1=cell[index2+2][index1];
			cell[index2][index1-1].add(cell,L1.getX(),x1, y1, y2, index2, index1-1,root,1,0,1,0,0,(x1+x2)/2,(y1+y2)/2,c,p,p1);
			cell[index2+1][index1].add(cell, x1, x2, y2,D1.getY() , index2+1, index1,root,1,0,0,0,1,(x1+x2)/2,(y1+y2)/2,c,p,p1);
			Cell R1=cell[index2][index1+2];
			cell[index2][index1+1].add(cell, x2,R1.getX(), y1, y2, index2, index1+1,root,1,1,0,0,0,(x1+x2)/2,(y1+y2)/2,c,p,p1);
		}
		else if(index2==row && index1!=0 && index1!=col) {
			Cell R1=cell[index2][index1+2];
			cell[index2][index1+1].add(cell, x2,R1.getX(), y1, y2, index2, index1+1,root,1,1,0,0,0,(x1+x2)/2,(y1+y2)/2,c,p,p1);
			Cell L1=cell[index2][index1-1];
			cell[index2][index1-1].add(cell,L1.getX(),x1, y1, y2, index2, index1-1,root,1,0,1,0,0,(x1+x2)/2,(y1+y2)/2,c,p,p1);
			Cell U1=cell[index2-1][index1];
			cell[index2-1][index1].add(cell, x1, x2,U1.getY(),y1, index2-1, index1,root,1,0,0,1,0,(x1+x2)/2,(y1+y2)/2,c,p,p1);
		}
		else if(index1==0 && index2!=0 && index2!=row) {
			Cell U1=cell[index2-1][index1];
			cell[index2-1][index1].add(cell, x1, x2,U1.getY(),y1, index2-1, index1,root,1,0,0,1,0,(x1+x2)/2,(y1+y2)/2,c,p,p1);
			Cell R1=cell[index2][index1+2];
			cell[index2][index1+1].add(cell, x2,R1.getX(), y1, y2, index2, index1+1,root,1,1,0,0,0,(x1+x2)/2,(y1+y2)/2,c,p,p1);
			Cell D1=cell[index2+2][index1];
			cell[index2+1][index1].add(cell, x1, x2, y2,D1.getY() , index2+1, index1,root,1,0,0,0,1,(x1+x2)/2,(y1+y2)/2,c,p,p1);
		}
		else if(index1==col && index2!=0 && index2!=row) {
			Cell L1=cell[index2][index1-1];
			cell[index2][index1-1].add(cell,L1.getX(),x1, y1, y2, index2, index1-1,root,1,0,1,0,0,(x1+x2)/2,(y1+y2)/2,c,p,p1);
			Cell U1=cell[index2-1][index1];
			cell[index2-1][index1].add(cell, x1, x2,U1.getY(),y1, index2-1, index1,root,1,0,0,1,0,(x1+x2)/2,(y1+y2)/2,c,p,p1);
			Cell D1=cell[index2+2][index1];
			cell[index2+1][index1].add(cell, x1, x2, y2,D1.getY() , index2+1, index1,root,1,0,0,0,1,(x1+x2)/2,(y1+y2)/2,c,p,p1);
		}
		else {
			Cell L1=cell[index2][index1-1];
			cell[index2][index1-1].add(cell,L1.getX(),x1, y1, y2, index2, index1-1,root,1,0,1,0,0,(x1+x2)/2,(y1+y2)/2,c,p,p1);
			Cell U1=cell[index2-1][index1];
			cell[index2-1][index1].add(cell, x1, x2,U1.getY(),y1, index2-1, index1,root,1,0,0,1,0,(x1+x2)/2,(y1+y2)/2,c,p,p1);
			Cell D1=cell[index2+2][index1];
			cell[index2+1][index1].add(cell, x1, x2, y2,D1.getY() , index2+1, index1,root,1,0,0,0,1,(x1+x2)/2,(y1+y2)/2,c,p,p1);
			Cell R1=cell[index2][index1+2];
			cell[index2][index1+1].add(cell, x2,R1.getX(), y1, y2, index2, index1+1,root,1,1,0,0,0,(x1+x2)/2,(y1+y2)/2,c,p,p1);
		}
	}
}